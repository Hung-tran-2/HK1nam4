package cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186.Adapter.AdapterMaytinh;
import cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186.dao.DBHelper;
import cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186.model.MayTinh;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton fa;
    ListView listView;
    DBHelper helper;
    Toolbar toolbar;
    List<MayTinh> listsach =new ArrayList<>();

    AdapterMaytinh adapter;
    MayTinh chon;

    int requestcode = 113, resultcode =115;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();

        helper = new DBHelper(MainActivity.this);
        helper.QueryData(DBHelper.SQL_Create_Table);

        addEvents();
        hienthisach();
    }

    private void addControls() {
        fa = findViewById(R.id.faThem);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        listView = findViewById(R.id.lvQlsach);
        registerForContextMenu(listView);
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if(v.getId() == R.id.lvQlsach)
        {
            getMenuInflater().inflate(R.menu.context_menu, menu);
        }

    }
    @Override
    public boolean onContextItemSelected(MenuItem item){
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int index = info.position;
        if (item.getItemId() == R.id.btnSua) {
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            chon = adapter.getItem(index);
            intent.putExtra("CHON", chon);
            startActivityForResult(intent, requestcode);
        } else if (item.getItemId() == R.id.btnXoa) {
            chon = adapter.getItem(index);
            helper.deleteSach(chon.getMa() + "");
            hienthisach();
        }

        return super.onContextItemSelected(item);
    }
    private void addEvents() {
        fa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivityForResult(intent,requestcode);
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data != null && data.hasExtra("TRA")) {
            MayTinh s = (MayTinh) data.getSerializableExtra("TRA");

            // Kiểm tra xem bản ghi đã tồn tại trong danh sách hay chưa
            boolean recordExists = false;
            for (MayTinh existingRecord : listsach) {
                if (existingRecord.getMa().equals(s.getMa())) {
                    recordExists = true;
                    break;
                }
            }

            if (recordExists) {
                // Bản ghi đã tồn tại, thực hiện cập nhật
                helper.updateSach(s);
            } else {
                // Bản ghi chưa tồn tại, thực hiện thêm mới
                helper.insertSach(s);
            }
        }
        hienthisach();
    }
    private void hienthisach() {
        listsach = (ArrayList<MayTinh>) helper.getAllbaihat();
        adapter = new AdapterMaytinh(
                MainActivity.this,
                R.layout.item_sach,
                listsach,
                helper
        );
        listView.setAdapter(adapter);
    }
    @Override
    protected void onDestroy() {
        helper.close();
        super.onDestroy();
    }
}