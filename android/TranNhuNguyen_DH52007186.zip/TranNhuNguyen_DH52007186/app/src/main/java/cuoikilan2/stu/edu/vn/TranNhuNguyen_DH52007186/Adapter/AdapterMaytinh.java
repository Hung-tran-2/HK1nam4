package cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186.R;
import cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186.dao.DBHelper;
import cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186.model.MayTinh;


public class AdapterMaytinh extends ArrayAdapter<MayTinh> {
    Activity context;
    int res;
    List<MayTinh> obj;
    DBHelper helper;
    public AdapterMaytinh(Activity context, int res, List<MayTinh> list, DBHelper helper)
    {
        super(context,res, list);
        this.context =context;
        this.res = res;
        this.obj = list;
        this.helper = helper;
    }


    @Override
    public View getView(int position,  View convertView,  ViewGroup parent) {
        LayoutInflater inflater =this.context.getLayoutInflater();
        View item = inflater.inflate(this.res, null);

        TextView ma =item.findViewById(R.id.txtMa);
        TextView ten =item.findViewById(R.id.txtTen);
        TextView tg =item.findViewById(R.id.txtTacgia);
        TextView tl =item.findViewById(R.id.txtthoiluong);
        final MayTinh bh = obj.get(position);
        ma.setText(bh.getMa());
        ten.setText(bh.getTen());
        tg.setText(bh.getSl()+"");
        tl.setText(bh.getGia()+"");

        return item;
    }
}
