package cuoikilan2.stu.edu.vn.TranNhuNguyen_DH52007186.model;

import java.io.Serializable;

public class MayTinh implements Serializable {
    private String ma;
    private String ten;
    private int sl;
    private float gia;

    public MayTinh() {
    }

    public MayTinh(String ma, String ten, int sl, float gia) {
        this.ma = ma;
        this.ten = ten;
        this.sl = sl;
        this.gia = gia;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public int getSl() {
        return sl;
    }

    public void setSl(int sl) {
        this.sl = sl;
    }

    public float getGia() {
        return gia;
    }

    public void setGia(float gia) {
        this.gia = gia;
    }

    @Override
    public String toString() {
        return "MayTinh{" +
                "ma='" + ma + '\'' +
                ", ten='" + ten + '\'' +
                ", sl=" + sl +
                ", gia=" + gia +
                '}';
    }
}
