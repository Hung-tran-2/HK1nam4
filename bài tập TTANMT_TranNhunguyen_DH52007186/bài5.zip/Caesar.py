def decrypytion(cipherText, key):
    alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    cipherText =cipherText.upper()
    result=""
    for letter in cipherText:
        if(letter in alpha):
            letter_index=(alpha.find(letter)-key)%len(alpha)
            result= result+alpha[letter_index]
        else:
            result=result+letter
    return result

def encryption(planText, key):
    alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    planText = planText.upper()
    result = ""
    for letter in planText:
        if (letter in alpha):
            letter_index = (alpha.find(letter) + key) % len(alpha)
            result = result + alpha[letter_index]
        else:
            result = result + letter
    return result
def main():
    while True:
        print("1. Ma hoa: ")
        print()
        print("2. Giai ma: ")
        ans = int(input())
        if ans==1:
            print("Nhap key= ")
            key = int(input())
            print("Nhap planText: ")
            planText=input()
            ecr=encryption(planText,key)
            print(ecr)
        else:
            print("Nhap key= ")
            key = int(input())
            print("Nhap cipherText: ")
            cipherText = input()
            print(decrypytion(cipherText,key))

        print("Do you continue: Y/N")
        contn=input()
        if(contn=="n"):
            break
        else:
            continue
if(__name__=="__main__"):
    main()