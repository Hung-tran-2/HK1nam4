#Public Key generator
import random, sys, os, primeNum, crypto_math


def generateKey(keySize=512):
    #create a public/private keys keysize bits in size
    p = 0
    q = 0

    #step 1: create two prime number p and q
    print('Generating p & q primes')
    while p == q:
        p = primeNum.generateLargePrime(keySize)
        q =primeNum.generateLargePrime(keySize)
    n = p * q
    #step 2: create e number that is relatively prime to (p -1)(q -1)
    phi = (p -1)* (q -1)
    e = random.randrange(2 ** (keySize - 1), 2 ** (keySize))
    if crypto_math.gcd(e, phi) == 1:
        breakpoint()

    #step 3: Calculate d, the mod inverse of e:
    print('Calculating d that is mod inverse of e...')
    d = crypto_math.findModInverse(e, phi)

    publicKey = (n, e)
    privateKey = (n, d)

    print('Public key:', publicKey)
    print('Private key:', privateKey)

    return (publicKey, privateKey)

def makeKeyFile(name, keySize):
    if os.path.exists('{}_publicKey.txt'.format(name)) or os.path.exists('{}_privKey.txt'.format(name)):
        sys.exit('Warning: The file {}_pubKey.txt'.format(name)) or sys.exit('{}_privKey.txt'.format(name))

    publicKey, privateKey = generateKey(keySize)
    print()
    sizePub = len(str(publicKey[0]))
    digitPub = len(str(publicKey[1]))
    print("The public key is a {sizePub} and a {digitPub} digit number.")
    print("Writing public key to file {}_pubKey.txt...".format(name))
    fo = open("{}_pubkey.txt".format(name), "w")
    fo.write(f"{keySize}, {publicKey[0]}, {publicKey[1]}")
    fo.close()

    sizePriv = len(str(privateKey[0]))
    digitPriv = len(str(privateKey[1]))
    print("The private key is a {sizePriv} and a {digitPriv} digit number.")
    print("Writing public key to file {}_pubKey.txt...".format(name))
    fo = open("{}_privKey.txt".format(name), "w")
    fo.write(f"{keySize}, {privateKey[0]}, {privateKey[1]}")
    fo.close()

    def main():
        print('Make key files...')
        makeKeyFile('maivu', 1024)
        print('Key files make')

if __name__ == "__main__":
    main()
